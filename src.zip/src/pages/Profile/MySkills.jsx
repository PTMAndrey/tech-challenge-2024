import React from 'react'

const MySkills = () => {
  return (
    <div>MySkills</div>
  )
}

export default MySkills