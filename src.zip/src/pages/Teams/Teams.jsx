import React from 'react'

const Teams = () => {
  return (
    <div>Teams</div>
  )
}

export default Teams