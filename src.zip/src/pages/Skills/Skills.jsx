import React from 'react'

const Skills = () => {
  return (
    <div>Skills</div>
  )
}

export default Skills