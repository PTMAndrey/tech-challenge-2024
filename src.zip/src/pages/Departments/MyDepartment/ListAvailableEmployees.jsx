import React, { Fragment } from "react";
import EmployeesCard from '../../../components/Card/EmployeesCard';
import styles from '../Departments.module.scss'
import { Col, Container, Row } from 'react-bootstrap';
import { TextRotationAngleupIcon, TextRotationAngledownIcon, FilterListIcon } from '../../imports/muiiconsMaterial';
import useStateProvider from "../../../hooks/useStateProvider";
import Pagination from "../../../components/Pagination/Pagination";


const ListAvailableEmployees = (props) => {
  const { pageSizeMyDepartmentEmployees, currentPageMyDepartmentEmployees, setCurrentPageMyDepartmentEmployees } = useStateProvider();

  return (
    <>
      <div onClick={() => props.toggleSortDirectionAndColumn('firstName')} className={styles.sortButtonCard}>
        <FilterListIcon />
        <p>Sort by department name </p>
        {props.sortDirection === 'Ascending' && props.sortBy === 'firstName' ? <TextRotationAngledownIcon /> : <TextRotationAngleupIcon />}
      </div>

      {props.currentTableData?.length >= 1 &&
        <Pagination
          data={props.rows}
          className={styles.paginationBar}
          totalCount={props.rows?.length}
          pageSize={pageSizeMyDepartmentEmployees}
          currentPage={currentPageMyDepartmentEmployees}
          onPageChange={page => setCurrentPageMyDepartmentEmployees(page)}
        />
      }
      <Container className={styles.employeesContainer}>
      <Row>
        {props.currentTableData?.map((user, index) =>
        (
          <Col key={`${user?.idUser}_${index}`}>
            <Fragment>
              {
                <EmployeesCard
                  key={user.idUser}
                  data={user}
                  handleOpenAddUpdate={props.handleOpenAddUpdate}
                  handleOpenDelete={props.handleOpenDelete}
                />
              }
            </Fragment>
          </Col>
        )
        )}
      </Row>
      </Container>
    </>
  )
}

export default ListAvailableEmployees