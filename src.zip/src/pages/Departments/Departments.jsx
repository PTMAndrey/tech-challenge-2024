import React, { useEffect, useState } from 'react'
import styles from './Departments.module.scss'
import { useLocation } from 'react-router';
import AdminDepartments from './AdminDepartments';
import MyDepartment from './MyDepartment';
import useAuthProvider from '../../hooks/useAuthProvider';
import useStateProvider from '../../hooks/useStateProvider';

const Departments = () => {
  const { user } = useAuthProvider();
  const location = useLocation();
  const currentTab = location.pathname.split("/")[2];
  console.log(currentTab);
  useEffect(() => {
    fetchDepartments(user?.idOrganisation);
    fetchUnassignedDepartmentManagers(user?.idOrganisation);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);




  const {fetchDepartments,
    fetchUnassignedDepartmentManagers,
    managersWithoutDepartments_dropdown,
  } = useStateProvider();
  const tabSelector = () => {
    switch (currentTab) {
      case "admin":
        return <AdminDepartments managersWithoutDepartments_dropdown={managersWithoutDepartments_dropdown}/>;
      case ("myDepartment"):
        return < MyDepartment />;
      default:
        break;
    }
  };
  return (
    <section className={styles.pageDepartments}>
      <div>{tabSelector()}</div>
    </section>

  );
}

export default Departments;